package org.uca;
import org.uca.aeroport.Compagnie;
import org.uca.aeroport.Vol;
import java.text.SimpleDateFormat;
public class Start {
    public static void main(String[] args) {
        System.out.println("INFORMATIONS DU VOL");
        Vol volFinal = new Vol();
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String dd = "21/10/2020 13:00";
        String da = "23/10/2020 02:15";
        try {
            volFinal.setDateDepart(format.parse(dd));
            volFinal.setDateArrivee(format.parse(da));
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors du formatage des dates");
        }
        System.out.println("Date d'arrivée : " + format.format(volFinal.getDateArrivee()));
        System.out.println("Durée du vol   : " + volFinal.obtenirDuree().toString().substring(2));
        System.out.println("\nTEST RELATION COMPAGNIE - VOLS");
        Vol vol = new Vol();
        vol.setNumero("ABC1");
        Vol vol2 = new Vol();
        vol2.setNumero("ABC2");
        Compagnie compagnie = new Compagnie();
        compagnie.setName("Air France");
        compagnie.addVol(vol);
        compagnie.addVol(vol2);
        System.out.println("\nCompagnie : " + compagnie.getName());
        System.out.println("Liste des vols :");
        for (Vol v : compagnie.getVols()) {
            System.out.println(" - Vol numéro : " + v.getNumero());
        }
        System.out.println("\nCompagnie associée au vol ABC1 : " + vol.getCompagnie().getName());
        System.out.println("Compagnie associée au vol ABC2 : " + vol2.getCompagnie().getName());
        System.out.println("\n Suppression de la compagnie pour le vol ABC2 ");
        vol2.setCompagnie(null);
        System.out.println("Compagnie du vol ABC2 après suppression : " + vol2.getCompagnie());
        System.out.println("\nListe des vols après modification :");
        for (Vol v : compagnie.getVols()) {
            System.out.println(" - Vol numéro : " + v.getNumero());
        }
        System.out.println("\n FIN DU PROGRAMME");
    }
}