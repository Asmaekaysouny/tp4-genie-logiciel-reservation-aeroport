package org.uca.reservation;

public enum EtatReservation {
    ANNULEE,
    PAYEE,
    CONFIRMEE
}
