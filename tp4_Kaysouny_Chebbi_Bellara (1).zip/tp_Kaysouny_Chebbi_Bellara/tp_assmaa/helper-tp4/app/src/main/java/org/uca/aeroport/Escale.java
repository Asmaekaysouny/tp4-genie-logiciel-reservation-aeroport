package org.uca.aeroport;

import java.util.Date;

public class Escale {
    private Date heureDepart;
    private Date heureArrivee;
    private Aeroport aeroport;

    public Escale() {}

    public Date getHeureDepart() { return heureDepart; }
    public void setHeureDepart(Date heureDepart) { this.heureDepart = heureDepart; }

    public Date getHeureArrivee() { return heureArrivee; }
    public void setHeureArrivee(Date heureArrivee) { this.heureArrivee = heureArrivee; }

    public Aeroport getAeroport() { return aeroport; }
    public void setAeroport(Aeroport aeroport) { this.aeroport = aeroport; }
}
