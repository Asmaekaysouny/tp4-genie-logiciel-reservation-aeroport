package org.uca.reservation;

import org.uca.aeroport.Vol;

public class Reservation {

    private Client client;
    private Passager passager;
    private Vol vol;
    private EtatReservation etat;

    public Reservation() {
    }

    // Client
    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        if (this.client != null) {
            this.client.removeReservationWithoutBidirectional(this);
        }
        this.client = client;
        if (this.client != null) {
            this.client.addReservationWithoutBidirectional(this);
        }
    }

    public void setClientWithoutBidirectional(Client client) {
        this.client = client;
    }

    // Passager
    public Passager getPassager() {
        return passager;
    }

    public void setPassager(Passager passager) {
        if (this.passager != null) {
            this.passager.removeReservationWithoutBidirectional(this);
        }
        this.passager = passager;
        if (this.passager != null) {
            this.passager.addReservationWithoutBidirectional(this);
        }
    }

    public void setPassagerWithoutBidirectional(Passager passager) {
        this.passager = passager;
    }

    // Vol
    public Vol getVol() {
        return vol;
    }

    public void setVol(Vol vol) {
        if (this.vol != null) {
            this.vol.removeReservationWithoutBidirectional(this);
        }
        this.vol = vol;
        if (this.vol != null) {
            this.vol.addReservationWithoutBidirectional(this);
        }
    }

    public void setVolWithoutBidirectional(Vol vol) {
        this.vol = vol;
    }

    // Etat
    public EtatReservation getEtat() {
        return etat;
    }

    public void setEtat(EtatReservation etat) {
        this.etat = etat;
    }
    
    // Annuler, confirmer
    public void annuler() {
        this.etat = EtatReservation.ANNULEE;
    }
    
    public void confirmer() {
        if (this.etat == EtatReservation.PAYEE) {
            this.etat = EtatReservation.CONFIRMEE;
        }
    }
}
