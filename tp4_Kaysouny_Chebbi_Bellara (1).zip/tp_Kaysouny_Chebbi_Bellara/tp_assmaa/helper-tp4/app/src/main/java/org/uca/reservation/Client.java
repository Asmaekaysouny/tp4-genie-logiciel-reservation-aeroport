package org.uca.reservation;

import java.util.ArrayList;
import java.util.Collection;

public class Client {
    private String nom;
    private Collection<Reservation> reservations = new ArrayList<>();

    public Client() {}

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public Collection<Reservation> getReservations() { return reservations; }

    public void setReservations(Collection<Reservation> reservations) {
        for (Reservation r : this.reservations) {
            r.setClientWithoutBidirectional(null);
        }
        this.reservations = reservations;
        if (this.reservations != null) {
            for (Reservation r : this.reservations) {
                r.setClientWithoutBidirectional(this);
            }
        }
    }

    public void addReservation(Reservation reservation) {
        reservation.setClientWithoutBidirectional(this);
        this.reservations.add(reservation);
    }

    public void removeReservation(Reservation reservation) {
        reservation.setClientWithoutBidirectional(null);
        this.reservations.remove(reservation);
    }

    protected void setReservationsWithoutBidirectional(Collection<Reservation> reservations) {
        this.reservations = reservations;
    }

    protected void addReservationWithoutBidirectional(Reservation reservation) {
        this.reservations.add(reservation);
    }

    protected void removeReservationWithoutBidirectional(Reservation reservation) {
        this.reservations.remove(reservation);
    }
}
