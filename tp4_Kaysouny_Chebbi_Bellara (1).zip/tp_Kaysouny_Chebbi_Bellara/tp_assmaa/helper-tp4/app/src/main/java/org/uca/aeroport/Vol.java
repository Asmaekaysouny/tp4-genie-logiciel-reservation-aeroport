package org.uca.aeroport;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import org.uca.reservation.Reservation;

public class Vol {

    private String numero;

    private Aeroport depart;

    private Aeroport arrivee;

    private Compagnie compagnie;

    private Date dateDepart;

    private Date dateArrivee;

    private boolean ouvert;

    private Collection<Escale> escales = new ArrayList<>();

    private Collection<Reservation> reservations = new ArrayList<>();

    public Vol() {
    }

    protected Vol(String numero) {
        this.numero = numero;
    }

    public Duration obtenirDuree() {
        if (this.dateDepart != null && this.dateArrivee != null) {
            return Duration.of(dateArrivee.getTime() - dateDepart.getTime(), ChronoUnit.MILLIS);
        }
        return null;
    }

    public Date getDateDepart() {
        return dateDepart;
    }

    public void setDateDepart(Date dateDepart) {
        this.dateDepart = dateDepart;
    }

    public Date getDateArrivee() {
        return dateArrivee;
    }

    public void setDateArrivee(Date dateArrivee) {
        this.dateArrivee = dateArrivee;
    }

    public Compagnie getCompagnie() {
        return compagnie;
    }

    public void setCompagnie(Compagnie compagnie) {
        if (compagnie != null) {
            compagnie.addVolWithoutBidirectional(this);
        }
        if (this.compagnie != null) {
            this.compagnie.removeVolWithoutBidirectional(this);
        }
        this.compagnie = compagnie;
    }

    protected void setCompagnieWithoutBidirectional(Compagnie compagnie) {
        this.compagnie = compagnie;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Aeroport getDepart() {
        return depart;
    }

    public void setDepart(Aeroport depart) {
        this.depart = depart;
    }

    public Aeroport getArrivee() {
        return arrivee;
    }

    public void setArrivee(Aeroport arrivee) {
        this.arrivee = arrivee;
    }

    public boolean isOuvert() {
        return ouvert;
    }

    public void setOuvert(boolean ouvert) {
        this.ouvert = ouvert;
    }

    public Collection<Escale> getEscales() {
        return escales;
    }

    public void setEscales(Collection<Escale> escales) {
        this.escales = escales;
    }

    public void addEscale(Escale escale) {
        this.escales.add(escale);
    }

    public void removeEscale(Escale escale) {
        this.escales.remove(escale);
    }

    public Collection<Reservation> getReservations() {
        return reservations;
    }

    public void setReservations(Collection<Reservation> reservations) {
        for (Reservation r : this.reservations) {
            r.setVolWithoutBidirectional(null);
        }
        this.reservations = reservations;
        if (this.reservations != null) {
            for (Reservation r : this.reservations) {
                r.setVolWithoutBidirectional(this);
            }
        }
    }

    public void addReservation(Reservation reservation) {
        reservation.setVolWithoutBidirectional(this);
        this.reservations.add(reservation);
    }

    public void removeReservation(Reservation reservation) {
        reservation.setVolWithoutBidirectional(null);
        this.reservations.remove(reservation);
    }

    public void setReservationsWithoutBidirectional(Collection<Reservation> reservations) {
        this.reservations = reservations;
    }

    public void addReservationWithoutBidirectional(Reservation reservation) {
        this.reservations.add(reservation);
    }

    public void removeReservationWithoutBidirectional(Reservation reservation) {
        this.reservations.remove(reservation);
    }

    @Override
    public boolean equals(Object obj) {
        try {
            return ((Vol) obj).getNumero().equals(this.numero);
        } catch (Exception e) {
            return false;
        }
    }
}
