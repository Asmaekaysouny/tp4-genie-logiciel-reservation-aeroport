package org.uca.reservation;

import java.util.ArrayList;
import java.util.Collection;

public class Passager {
    private String nom;
    private Collection<Reservation> reservations = new ArrayList<>();

    public Passager() {}

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public Collection<Reservation> getReservations() { return reservations; }

    public void setReservations(Collection<Reservation> reservations) {
        for (Reservation r : this.reservations) {
            r.setPassagerWithoutBidirectional(null);
        }
        this.reservations = reservations;
        if (this.reservations != null) {
            for (Reservation r : this.reservations) {
                r.setPassagerWithoutBidirectional(this);
            }
        }
    }

    public void addReservation(Reservation reservation) {
        reservation.setPassagerWithoutBidirectional(this);
        this.reservations.add(reservation);
    }

    public void removeReservation(Reservation reservation) {
        reservation.setPassagerWithoutBidirectional(null);
        this.reservations.remove(reservation);
    }

    protected void setReservationsWithoutBidirectional(Collection<Reservation> reservations) {
        this.reservations = reservations;
    }

    protected void addReservationWithoutBidirectional(Reservation reservation) {
        this.reservations.add(reservation);
    }

    protected void removeReservationWithoutBidirectional(Reservation reservation) {
        this.reservations.remove(reservation);
    }
}
